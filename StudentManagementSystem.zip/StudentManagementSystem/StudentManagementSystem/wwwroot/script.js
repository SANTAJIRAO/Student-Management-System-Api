﻿const API_URL = 'https://your-api-url.com/api';
let token = localStorage.getItem('token');

function showRegistration() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registrationForm').style.display = 'block';
}

function showLogin() {
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('registrationForm').style.display = 'none';
}

function showDashboard() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registrationForm').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
}

async function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch(`${API_URL}/auth/student/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.token);
            token = data.token;
            showDashboard();
        } else {
            alert('Login failed. Please check your credentials.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during login.');
    }
}

async function register() {
    const student = {
        firstName: document.getElementById('regFirstName').value,
        lastName: document.getElementById('regLastName').value,
        email: document.getElementById('regEmail').value,
        password: document.getElementById('regPassword').value,
        dateOfBirth: document.getElementById('regDob').value,
        rollNumber: document.getElementById('regRollNumber').value
    };

    try {
        const response = await fetch(`${API_URL}/auth/student/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(student)
        });

        if (response.ok) {
            alert('Registration successful! Please login.');
            showLogin();
        } else {
            alert('Registration failed. Please try again.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during registration.');
    }
}

async function markAttendance() {
    try {
        const response = await fetch(`${API_URL}/student/attendance`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            alert('Attendance marked successfully!');
        } else {
            alert('Failed to mark attendance.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while marking attendance.');
    }
}

async function getProfile() {
    try {
        const response = await fetch(`${API_URL}/student/profile`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById('profileData').innerText = JSON.stringify(data);
        } else {
            alert('Failed to retrieve profile data.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while fetching profile data.');
    }
}

function logout() {
    localStorage.removeItem('token');
    token = null;
    showLogin();
}

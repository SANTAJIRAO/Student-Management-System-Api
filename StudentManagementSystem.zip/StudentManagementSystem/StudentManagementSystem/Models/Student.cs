﻿namespace StudentManagementSystem.Models
{
    public class Student
    {
        internal object Username;

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string StudentCode { get; set; }
        public DateTime DateOfBirth { get; set; }
        public bool IsActive { get; set; }
        public virtual ICollection<Attendances> Attendances { get; set; }
    }
}


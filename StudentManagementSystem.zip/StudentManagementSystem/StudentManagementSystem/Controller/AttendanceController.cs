﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;
using System.Security.Claims;

namespace StudentManagementSystem.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttendanceController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AttendanceController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("mark")]
        [Authorize(Roles = "Student")]
        public async Task<IActionResult> MarkAttendance()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var student = await _context.Students.FindAsync(userId);

            if (student == null)
                return NotFound(new { message = "Student not found" });

            var attendance = new Attendances
            {
                StudentId = student.Id,
                Date = DateTime.UtcNow.Date,
                IsPresent = true
            };

            _context.Attendances.Add(attendance);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Attendance marked successfully" });
        }

        [HttpGet("history")]
        [Authorize(Roles = "Student,Teacher")]
        public async Task<IActionResult> GetAttendanceHistory(
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate,
            [FromQuery] int? studentId)
        {
            var query = _context.Attendances.AsQueryable();

            if (User.IsInRole("Student"))
            {
                var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
                query = query.Where(a => a.StudentId == userId);
            }
            else if (studentId.HasValue)
            {
                query = query.Where(a => a.StudentId == studentId.Value);
            }

            if (startDate.HasValue)
                query = query.Where(a => a.Date >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(a => a.Date <= endDate.Value);

            var attendances = await query
                .Include(a => a.Student)
                .OrderByDescending(a => a.Date)
                .Select(a => new
                {
                    a.Date,
                    a.IsPresent,
                    a.MarkedAt,
                    StudentName = a.Student.Username
                })
                .ToListAsync();

            return Ok(attendances);
        }
    }
    
    
}


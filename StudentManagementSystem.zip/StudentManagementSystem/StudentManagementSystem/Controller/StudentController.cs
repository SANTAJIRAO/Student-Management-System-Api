﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;
using System.Security.Claims;

namespace StudentManagementSystem.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public StudentController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("attendance")]
        [Authorize(Roles = "Student")]
        public async Task<IActionResult> MarkAttendance()
        {
            var studentId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var attendance = new Attendances
            {
                StudentId = studentId,
                Date = DateTime.Today,
                IsPresent = true
            };

            _context.Attendances.Add(attendance);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("attendance")]
        [Authorize(Roles = "Student,Teacher")]
        public async Task<IActionResult> GetAttendance(int? studentId = null)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var role = User.FindFirst(ClaimTypes.Role)?.Value;

            IQueryable<Attendances> query = _context.Attendances;

            if (role == "Student")
            {
                query = query.Where(a => a.StudentId == userId);
            }
            else if (role == "Teacher" && studentId.HasValue)
            {
                query = query.Where(a => a.StudentId == studentId.Value);
            }

            var attendances = await query
                .Include(a => a.Student)
                .OrderByDescending(a => a.Date)
                .ToListAsync();

            return Ok(attendances);
        }
    }
}


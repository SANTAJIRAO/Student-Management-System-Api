﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.DTOs;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IJwtService _jwtService;

        public AuthController(ApplicationDbContext context, IJwtService jwtService)
        {
            _context = context;
            _jwtService = jwtService;
        }

        [HttpPost("login")]
        public async Task<ActionResult<LoginResponseDTO>> Login(LoginRequestDTO request)
        {
            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.Email == request.Email);

            if (student != null && BCrypt.Net.BCrypt.Verify(request.Password, student.PasswordHash))
            {
                var token = _jwtService.GenerateToken(student.Id.ToString(), "Student");
                return new LoginResponseDTO
                {
                    Token = token,
                    Role = "Student",
                    Username = $"{student.FirstName} {student.LastName}"
                };
            }

            var teacher = await _context.Teachers
                .FirstOrDefaultAsync(t => t.Email == request.Email);

            if (teacher != null && BCrypt.Net.BCrypt.Verify(request.Password, teacher.PasswordHash))
            {
                var token = _jwtService.GenerateToken(teacher.Id.ToString(), "Teacher");
                return new LoginResponseDTO
                {
                    Token = token,
                    Role = "Teacher",
                    Username = $"{teacher.FirstName} {teacher.LastName}"
                };
            }

            return Unauthorized();
        }
    }
}
